package org.project.regist.commons;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.project.regist.service.MemberService;
import org.project.regist.vo.MemberVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.util.WebUtils;


//회원탈퇴 신청 여부
public class ResignInterceptor extends HandlerInterceptorAdapter {

    private static final Logger logger = LoggerFactory.getLogger(ResignInterceptor.class);
    private MemberService memberService;
    

    
    //회원탈퇴 진행중인 회원이 로그인하였을때;
    @Override
    public boolean preHandle(HttpServletRequest req,
       HttpServletResponse res, Object obj) throws Exception {
     
     HttpSession session = req.getSession();
     
     
     //미로그인 회원일때;
     if(session.getAttribute("resignchk") == null) {
    	 
    	 res.sendRedirect("/");
    	 
    	 return false;
    	 
     }else {
     
    //일반 회원이 로그인하였을 때;
     int chk = (int)session.getAttribute("resignchk");
     
     //탈퇴 테이블 조회하여 중복값이 0이 도출될 경우, 일반 상태로 사용, 그게 아니라면 무조건 철회페이지만 보여주기
     //회원탈퇴 신청을 한 회원이 로그인하였을 경우, DEL_MEMBER 테이블을 조회하여 중복값을 찾아 리턴해준다;
     if(chk == 1) {
      res.sendRedirect("/member/resigncancel");
      return false;
     }
     
     return true;
    }
    }
   }



