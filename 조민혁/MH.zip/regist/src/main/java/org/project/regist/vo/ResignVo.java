package org.project.regist.vo;

import java.util.Date;

public class ResignVo {

	private int delMemberNum;
	//private int memberNum; //중복값
	//private String memberId; //중복값
	private boolean timeOver;
	private Date delDate;
	
	private MemberVo memberVo;

	public int getDelMemberNum() {
		return delMemberNum;
	}

	public void setDelMemberNum(int delMemberNum) {
		this.delMemberNum = delMemberNum;
	}

	public boolean isTimeOver() {
		return timeOver;
	}

	public void setTimeOver(boolean timeOver) {
		this.timeOver = timeOver;
	}

	public Date getDelDate() {
		return delDate;
	}

	public void setDelDate(Date delDate) {
		this.delDate = delDate;
	}

	public MemberVo getMemberVo() {
		return memberVo;
	}

	public void setMemberVo(MemberVo memberVo) {
		this.memberVo = memberVo;
	}
	
	
	
	
	
	
	
	
}
